<?php
    $mail_host = "manzoleopoldo@gmail.com";
    $mail_port = "587";
    $mail_sender_email = ""; //sender
    $mail_sender_password = ""; //sender
    $mail_sender_name = "SQKII Clean Inquire Form";
?>