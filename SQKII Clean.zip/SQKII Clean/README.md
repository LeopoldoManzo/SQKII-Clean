# IT-Company-Website

## Overview

The project “IT Company Website” is a responsive website made using HTML, CSS, Bootstrap and JavaScript. As it is responsive, it works well on all devices. The website includes modules like About, Services, Portfolio, Team, Career, Contact and FAQ. Whenever anyone submits the contact form or career form, an email is sent on company’s email id so that they get notified about it and can communicate with that person soon. The website contains all the modules that meet the project requirement and is doing all the work accurately.

## Website Link

Go check this website!!
https://priyansh42.github.io/IT-Company-Website/

##

__NOTE: Please be aware that the PHP Mailer feature is not functional on the deployed website. To utilize it, you'll need to download the entire project and run it locally on your computer using XAMPP or WAMP.__
__Additionally, you'll have to set up the sender's credentials in the 'mailing/mailingvariables.php' file. In the 'contactme.php' and 'careers.php' files, you should specify the receiver's email address. Don't forget to provide the path to the 'tmp-uploads' folder in 'careers.php' file to store uploaded files.__
